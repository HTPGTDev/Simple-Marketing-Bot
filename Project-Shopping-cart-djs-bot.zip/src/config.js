module.exports = {
  prefix: "!",
  owner: "Owner-id",
  token: "Bot-token",
}
